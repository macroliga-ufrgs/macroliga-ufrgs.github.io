# Gráficos no padrão MacroLiga (R + ggplot2)

Este pacote de arquivos faz gráficos com a identidade visual da MacroLiga UFRGS: cores, fontes, fundo, rótulos e tamanhos certos para o Instagram, o LinkedIn e o fascículo. Você monta o gráfico com o `ggplot2`, como de costume, e o tema cuida da aparência.

**O que tem na pasta**

| Arquivo | O que é |
| --- | --- |
| `tema_macroliga.R` | O tema: todas as funções. É o único arquivo que você precisa carregar |
| `exemplos.R` | 14 gráficos completos, com dados reais do BCB, do IBGE e do Tesouro |
| `LEIA-ME.md` | Este guia |
| `exemplo*.png` | O resultado de cada exemplo, para consulta |

**Sumário**

1. [Instalação](#instalação)
2. [Seu primeiro gráfico](#seu-primeiro-gráfico)
3. [Como montar qualquer gráfico](#como-montar-qualquer-gráfico)
4. [Qual gráfico usar](#qual-gráfico-usar)
5. [As opções mais importantes](#as-opções-mais-importantes)
6. [Receitas por tipo de gráfico](#receitas-por-tipo-de-gráfico)
7. [Baixar dados](#baixar-dados)
8. [Regras do padrão](#regras-do-padrão)
9. [Problemas comuns](#problemas-comuns)
10. [Lista de todas as funções](#lista-de-todas-as-funções)

---

## Instalação

Faça isto uma vez por computador.

**1. Instale as fontes.** Baixe a [Inter](https://fonts.google.com/specimen/Inter) e a [Libre Baskerville](https://fonts.google.com/specimen/Libre+Baskerville) no Google Fonts (botão "Get font" e depois "Download all"). Descompacte e instale os arquivos `.ttf`:
- Windows: clique com o botão direito em cada arquivo e escolha **Instalar para todos os usuários**.
- Mac: dê dois cliques no arquivo e clique em **Instalar fonte**.

**2. Instale os pacotes do R.** Rode no console:

```r
install.packages(c("ggplot2", "scales", "ragg", "systemfonts", "jsonlite", "ggrepel"))
```

| Pacote | Para quê |
| --- | --- |
| `ggplot2` e `scales` | Fazer os gráficos (obrigatórios) |
| `ragg` | Exportar a imagem nítida e com as fontes certas |
| `systemfonts` | Encontrar as fontes instaladas |
| `jsonlite` | Baixar dados do BCB e do IBGE |
| `ggrepel` | Afastar rótulos dos pontos na dispersão (opcional) |

**3. Feche e abra o R (ou o RStudio) de novo**, para ele enxergar as fontes novas.

**4. No RStudio, ative o motor gráfico AGG** em *Tools › Global Options › General › Graphics › Backend: AGG*. Sem isso, a prévia na aba *Plots* pode mostrar outra fonte (o arquivo exportado sai certo de qualquer forma).

**Para conferir se deu certo**, rode:

```r
source("tema_macroliga.R", encoding = "UTF-8")
```

Se nenhuma mensagem aparecer, está tudo pronto. Se aparecer `[MacroLiga] Inter e/ou Libre Baskerville não encontradas`, as fontes não foram instaladas ou o R não foi reiniciado.

---

## Seu primeiro gráfico

**1. Deixe o `tema_macroliga.R` acessível.** O jeito mais simples é salvar o seu script na mesma pasta do tema. No RStudio, use *Session › Set Working Directory › To Source File Location* para o R "olhar" para essa pasta. Se o tema estiver em outro lugar, passe o caminho completo: `source("C:/caminho/para/tema_macroliga.R", encoding = "UTF-8")`.

**2. Rode o código abaixo.** Ele baixa a inflação em 12 meses do Banco Central e salva o gráfico pronto para o post "Gráfico Comentado" (precisa de internet):

```r
source("tema_macroliga.R", encoding = "UTF-8")        # carrega o tema

ipca <- sgs(13522, inicio = "01/01/2020")             # IPCA em 12 meses (BCB)

g <- ggplot(ipca, aes(x = data, y = valor)) +
  geom_line(colour = cores_macroliga[["azul_marinho"]], linewidth = 1.1) +
  rotulos_finais(ipca, x = "data", y = "valor", formato = pct_br(0.01)) +
  scale_x_date(date_labels = "%Y", expand = expansion(mult = c(0.01, 0.10))) +
  scale_y_continuous(labels = pct_br()) +
  labs(x = NULL, y = NULL) +
  theme_macroliga()

g                                                     # mostra a prévia
salvar_macroliga(g, "ipca_12m.png", "grafico_comentado")
```

O que cada linha faz:

| Linha | O que faz |
| --- | --- |
| `sgs(13522, ...)` | Baixa a série 13522 do SGS e devolve uma tabela com as colunas `data` e `valor` |
| `ggplot(ipca, aes(x = data, y = valor))` | Diz qual tabela usar e qual coluna vai em cada eixo |
| `geom_line(...)` | Desenha a linha em azul-marinho |
| `rotulos_finais(...)` | Põe um ponto vermelho no último dado, com o valor escrito ao lado |
| `scale_x_date(...)` | Mostra só o ano no eixo x e deixa 10% de espaço à direita para o rótulo |
| `scale_y_continuous(labels = pct_br())` | Escreve o eixo y como porcentagem no formato brasileiro (4,5%) |
| `labs(x = NULL, y = NULL)` | Tira os títulos dos eixos (nas redes, a unidade vai no template do Canva) |
| `theme_macroliga()` | Aplica o visual da MacroLiga. Vem sempre depois das escalas |
| `salvar_macroliga(...)` | Salva o PNG no tamanho exato da área do template |

> **A prévia não é o resultado final.** A aba *Plots* tem outro tamanho e outra proporção. Abra o PNG salvo para conferir como o gráfico vai ficar.

---

## Como montar qualquer gráfico

Todo gráfico segue a mesma receita, de cima para baixo:

```text
ggplot(dados, aes(...))      1. dados e eixos
  + camadas de fundo         2. faixas e períodos sombreados (banda(), periodos())
  + geom_...()               3. a forma: linha, coluna, ponto...
  + funções de apoio         4. rótulos, linha do zero (rotulos_finais(), linha_zero()...)
  + scale_...()              5. escalas: cores e formato dos eixos
  + labs(...)                6. títulos (nas redes, x = NULL e y = NULL)
  + theme_macroliga(...)     7. o tema, sempre no fim
salvar_macroliga(...)        8. exportar
```

A ordem das camadas importa: o que vem antes fica por baixo. Por isso a faixa sombreada vem antes da linha, e a linha do zero vem depois das colunas.

### O formato dos dados

O ggplot trabalha com **uma linha por observação**. Para várias séries, use o **formato longo**: uma coluna com o nome da série e outra com o valor.

```text
Formato largo (não serve)          Formato longo (serve)
data        IPCA   IGP-M           data        serie   valor
2025-01-01  4,6    3,0             2025-01-01  IPCA    4,6
2025-02-01  5,1    3,2             2025-01-01  IGP-M   3,0
                                   2025-02-01  IPCA    5,1
                                   2025-02-01  IGP-M   3,2
```

Para converter do largo para o longo, use o pacote `tidyr` (`install.packages("tidyr")`):

```r
largo <- data.frame(data  = as.Date(c("2025-01-01", "2025-02-01")),
                    IPCA  = c(4.6, 5.1),
                    IGPM  = c(3.0, 3.2))
longo <- tidyr::pivot_longer(largo, cols = c(IPCA, IGPM),
                             names_to = "serie", values_to = "valor")
```

As funções do tema recebem **o nome das colunas entre aspas**: `rotulos_finais(longo, x = "data", y = "valor", grupo = "serie")`.

---

## Qual gráfico usar

| Quero mostrar... | Gráfico | Receita | Exemplo em `exemplos.R` |
| --- | --- | --- | --- |
| Como uma série evoluiu no tempo | Linha | [Linha](#linha-uma-série) | 1, 3 |
| 2 a 4 séries na mesma unidade | Linhas coloridas | [Comparação](#comparação-de-2-a-4-séries) | 2 |
| Variações mês a mês, com altas e quedas | Colunas | [Colunas](#colunas) | 4 |
| Quem é maior ou menor (ranking) | Barras horizontais | [Ranking](#barras-horizontais-ranking) | 5, 6 |
| De que é feito um total, ao longo do tempo | Colunas empilhadas | [Contribuições](#contribuições-empilhadas) | 7 |
| Uma série contra uma meta ou intervalo | Linha com faixa | [Faixa](#linha-com-faixa-meta) | 8 |
| Uma série com períodos marcados | Linha com sombreado | [Períodos](#períodos-sombreados) | 9 |
| A relação entre duas variáveis | Dispersão | [Dispersão](#dispersão) | 10 |
| Antes e depois, por categoria | Haltere | [Haltere](#haltere) | 11 |
| Como se chega de um número a outro | Cascata | [Cascata](#cascata) | 12 |
| Mais de 4 séries | Pequenos múltiplos | [Pequenos múltiplos](#pequenos-múltiplos) | 13 |
| Taxas por prazo (estrutura a termo) | Curva de juros | [Curva](#curva-de-juros) | 14 |

**Evite:** pizza e rosca (compare com barras), gráficos 3D e **dois eixos y** (faça dois gráficos ou converta para índice com base 100).

---

## As opções mais importantes

### `theme_macroliga()`: a aparência

Forma geral, com os valores padrão:

```text
theme_macroliga(base_size = 16, fundo = "offwhite", grade = "y", eixo = "x")
```

| Opção | Valores | O que faz | Quando mudar |
| --- | --- | --- | --- |
| `base_size` | número (padrão `16`) | Tamanho de todos os textos | `10` para o fascículo; `14` com muitos painéis |
| `fundo` | `"offwhite"` (padrão), `"branco"`, `"transparente"` | Cor do fundo | Raramente: `salvar_macroliga()` já deixa transparente o que vai para o fascículo |
| `grade` | `"y"` (padrão), `"x"`, `"ambas"`, `"nenhuma"` | Quais linhas de grade aparecem | `"x"` em barras horizontais e haltere; `"ambas"` na dispersão |
| `eixo` | `"x"` (padrão), `"y"`, `"nenhum"` | Onde fica a linha escura do eixo | `"nenhum"` em colunas, barras e cascata (use `linha_zero()` no lugar) |

Exemplos:

```r
theme_macroliga()                                # linhas no tempo
theme_macroliga(eixo = "nenhum")                 # colunas com valores negativos
theme_macroliga(grade = "x", eixo = "nenhum")    # ranking em barras horizontais
theme_macroliga(base_size = 10)                  # figura do fascículo
```

Para ajustar um detalhe, acrescente `theme()` **depois** do tema: `theme_macroliga() + theme(legend.position = "none")`.

### `salvar_macroliga()`: exportar

Forma geral, com os valores padrão:

```text
salvar_macroliga(grafico, arquivo, formato = "grafico_comentado", transparente = NULL)
```

| Formato | Tamanho | Onde usar |
| --- | --- | --- |
| `"grafico_comentado"` | 1776 × 1380 px | Área do gráfico no template "Gráfico Comentado" |
| `"carrossel"` | 1776 × 1600 px | Área cinza da lâmina de gráfico do carrossel |
| `"linkedin"` | 2400 × 1254 px | Post horizontal no LinkedIn |
| `"vertical"` | 2160 × 2700 px | Post retrato 4:5 no Instagram, para rankings longos |
| `"publicacao"` | 16 × 10 cm, 300 dpi | Figura do fascículo |
| `"publicacao_vertical"` | 16 × 20 cm, 300 dpi | Figura alta no fascículo, para rankings longos |

- **Fundo:** os formatos de publicação saem com **fundo transparente**, para não marcar a página do fascículo. Os das redes saem em off-white, igual aos templates do Canva. Para forçar, use `transparente = TRUE` ou `FALSE`.
- **Vertical:** só para listas longas de categorias, como as 27 UFs. Séries no tempo ficam sempre na horizontal. A função avisa quando o formato não combina com o gráfico (o arquivo é salvo mesmo assim).
- **Fascículo:** use também `theme_macroliga(base_size = 10)` e `tamanho = 3.4` nas funções de rótulo, senão o texto fica grande demais.

```r
salvar_macroliga(g, "ipca.png", "carrossel")
salvar_macroliga(g, "ipca_fasciculo.png", "publicacao")                   # transparente
salvar_macroliga(g, "ipca_fasciculo_branco.png", "publicacao", transparente = FALSE)
```

### Cores

```r
cores_macroliga[["azul_marinho"]]   # "#083D6B"  série principal
cores_macroliga[["vermelho"]]       # "#D51E23"  destaque
cores_macroliga[["grafite"]]        # "#1F2933"  textos e eixos
cores_macroliga[["contexto"]]       # "#9AA5B1"  séries de fundo e "Outros"
cores_macroliga[["grade"]]          # "#D9D4CA"  linhas de grade
cores_macroliga[["offwhite"]]       # "#FAF8F4"  fundo
```

Com 2 a 4 séries, use `scale_colour_macroliga()` (linhas e pontos) ou `scale_fill_macroliga()` (colunas e áreas). As cores entram sempre na mesma ordem: azul, vermelho, âmbar e verde. A série que vem primeiro nos níveis do fator recebe o azul. Para escolher a ordem, transforme a coluna em fator:

```r
longo$serie <- factor(longo$serie, levels = c("IPCA", "IGPM"))   # IPCA azul, IGP-M vermelho
```

**Mais de 4 séries:** some as menores numa categoria chamada exatamente `"Outros"`, que sempre fica cinza. Se nem assim couber, use [pequenos múltiplos](#pequenos-múltiplos).

```r
d <- data.frame(data  = rep(as.Date("2025-01-01"), 6),
                serie = c("Soja", "Petróleo", "Minério", "Carne", "Café", "Açúcar"),
                valor = c(40, 30, 20, 5, 3, 2))
principais <- c("Soja", "Petróleo", "Minério")
d$serie <- ifelse(d$serie %in% principais, d$serie, "Outros")
d <- aggregate(valor ~ data + serie, data = d, FUN = sum)
d$serie <- factor(d$serie, levels = c(principais, "Outros"))
```

### Números, datas e prazos no formato brasileiro

Use estas funções em `labels =` das escalas e em `formato =` das funções de rótulo. O argumento é a precisão: `0.1` = uma casa decimal, `0.01` = duas, `1` = inteiro.

| Função | Exemplo | Resultado |
| --- | --- | --- |
| `num_br()` | `num_br(0.1)(1234.56)` | `"1.234,6"` |
| `pct_br()` | `pct_br(0.1)(10.5)` | `"10,5%"` (o valor já deve estar em %) |
| `mes_br()` | `mes_br()(as.Date("2025-01-01"))` | `"jan/25"` |
| `anos_br()` | `anos_br()(c(1, 5, 10))` | `"1 ano"`, `"5 anos"`, `"10 anos"` |
| `fonte_macroliga()` | `fonte_macroliga("IBGE")` | `"Fonte: IBGE. Elaboração: MacroLiga UFRGS."` |

```r
scale_y_continuous(labels = pct_br())                          # eixo em %
scale_x_date(labels = mes_br(), date_breaks = "3 months")      # eixo com jan/25, abr/25...
rotulos_finais(d, "data", "valor", formato = num_br(1))        # rótulo inteiro
```

### `rotulos_finais()`: o valor no último dado

Forma geral, com os valores padrão:

```text
rotulos_finais(dados, x, y, grupo = NULL, faceta = NULL, formato = num_br(0.1), tamanho = 5.2)
```

| Opção | O que faz |
| --- | --- |
| `dados`, `x`, `y` | A tabela e os nomes das colunas (entre aspas) |
| `grupo` | Coluna das séries. Sem ela: ponto vermelho e só o valor. Com ela: ponto na cor da série e "Nome  valor" |
| `faceta` | Coluna usada em `facet_wrap()`: marca o último dado de cada painel |
| `formato` | Como escrever o número (`pct_br(0.01)`, `num_br(1)`...) |
| `tamanho` | Tamanho do texto: `5.2` nas redes, `3.4` no fascículo |

O rótulo fica à direita do último ponto. **Se ele for cortado**, aumente o espaço à direita do eixo x: `scale_x_date(expand = expansion(mult = c(0.01, 0.15)))`. O segundo número é a folga à direita (0,15 = 15%).

---

## Receitas por tipo de gráfico

As receitas usam dados ilustrativos, digitados no próprio código, para você poder copiar, rodar e trocar pelos seus dados. Todas supõem que você já rodou `source("tema_macroliga.R", encoding = "UTF-8")`.

### Linha (uma série)

Azul-marinho, com o último dado em vermelho.

```r
dados <- data.frame(
  data  = seq(as.Date("2024-01-01"), by = "month", length.out = 24),
  valor = c(4.5, 4.3, 3.9, 3.7, 3.9, 4.2, 4.5, 4.2, 4.4, 4.8, 4.9, 4.8,
            4.6, 5.1, 5.5, 5.5, 5.3, 5.4, 5.2, 5.1, 5.2, 4.7, 4.5, 4.3)
)

g <- ggplot(dados, aes(data, valor)) +
  geom_line(colour = cores_macroliga[["azul_marinho"]], linewidth = 1.1) +
  rotulos_finais(dados, x = "data", y = "valor", formato = pct_br(0.1)) +
  scale_x_date(labels = mes_br(), date_breaks = "6 months",
               expand = expansion(mult = c(0.01, 0.12))) +
  scale_y_continuous(labels = pct_br(), limits = c(0, NA),
                     expand = expansion(mult = c(0, 0.05))) +
  labs(x = NULL, y = NULL) +
  theme_macroliga()

salvar_macroliga(g, "linha.png", "grafico_comentado")
```

- Para uma série que muda em degraus (como a Selic), troque `geom_line()` por `geom_step()`.
- `limits = c(0, NA)` faz o eixo começar no zero. Tire essa opção se a série não fizer sentido a partir do zero (ex.: um índice).

**Versão para o fascículo ou o site** (com título, subtítulo e fonte):

```r
g_pub <- ggplot(dados, aes(data, valor)) +
  geom_line(colour = cores_macroliga[["azul_marinho"]], linewidth = 0.8) +
  rotulos_finais(dados, x = "data", y = "valor", formato = pct_br(0.1), tamanho = 3.4) +
  scale_x_date(labels = mes_br(), date_breaks = "6 months",
               expand = expansion(mult = c(0.01, 0.12))) +
  scale_y_continuous(labels = pct_br()) +
  labs(title = "Inflação volta a cair no fim de 2025",
       subtitle = "IPCA acumulado em 12 meses, %",
       caption = fonte_macroliga("IBGE"),
       x = NULL, y = NULL) +
  theme_macroliga(base_size = 10)

salvar_macroliga(g_pub, "linha_fasciculo.png", "publicacao")
```

O título deve **afirmar o fato** que o gráfico mostra, e não só descrever a variável.

### Comparação de 2 a 4 séries

```r
comp <- data.frame(
  data  = rep(seq(as.Date("2025-01-01"), by = "month", length.out = 12), 3),
  serie = rep(c("IPCA", "IGP-M", "INPC"), each = 12),
  valor = c(4.6, 5.1, 5.5, 5.5, 5.3, 5.4, 5.2, 5.1, 5.2, 4.7, 4.5, 4.3,
            8.4, 8.6, 8.6, 8.5, 7.0, 4.4, 2.9, 2.5, 2.8, 1.9, 0.9, -0.5,
            4.2, 4.9, 5.2, 5.3, 5.1, 5.2, 5.1, 5.0, 5.1, 4.5, 4.2, 4.1)
)
comp$serie <- factor(comp$serie, levels = c("IPCA", "IGP-M", "INPC"))

g <- ggplot(comp, aes(data, valor, colour = serie)) +
  geom_line(linewidth = 1) +
  rotulos_finais(comp, x = "data", y = "valor", grupo = "serie", formato = pct_br(0.1)) +
  scale_colour_macroliga() +
  scale_x_date(labels = mes_br(), date_breaks = "3 months",
               expand = expansion(mult = c(0.01, 0.22))) +
  scale_y_continuous(labels = pct_br()) +
  labs(x = NULL, y = NULL) +
  theme_macroliga()

salvar_macroliga(g, "comparacao.png", "carrossel")
```

- Com várias séries, a legenda fica no topo **e** cada linha tem o nome escrito no fim (`grupo = "serie"`).
- Se as séries tiverem unidades diferentes, converta para índice com base 100 (`100 * valor / valor[1]` em cada série) em vez de usar dois eixos.

### Colunas

Azul-marinho para valores positivos e vermelho para negativos.

```r
mensal <- data.frame(
  data  = seq(as.Date("2025-01-01"), by = "month", length.out = 12),
  valor = c(0.16, 1.31, 0.56, 0.43, 0.26, 0.24, 0.26, -0.11, 0.48, 0.09, 0.18, 0.33)
)

g <- ggplot(mensal, aes(data, valor, fill = sinal(valor))) +
  geom_col() +
  linha_zero() +
  rotulos_barras(mensal, "data", "valor", formato = pct_br(0.01), quais = "ultimo") +
  scale_fill_sinal() +
  scale_x_date(labels = mes_br(), date_breaks = "2 months",
               expand = expansion(mult = 0.02)) +
  scale_y_continuous(labels = pct_br(0.1), expand = expansion(mult = 0.1)) +
  labs(x = NULL, y = NULL) +
  theme_macroliga(eixo = "nenhum")

salvar_macroliga(g, "colunas.png", "grafico_comentado")
```

| Peça | O que faz |
| --- | --- |
| `fill = sinal(valor)` + `scale_fill_sinal()` | Pinta cada coluna conforme o sinal |
| `linha_zero()` | Linha de base no zero, por cima das colunas |
| `rotulos_barras(..., quais = "ultimo")` | Escreve só o valor da última coluna. Com poucas colunas, use `quais = "todos"` |
| `theme_macroliga(eixo = "nenhum")` | Tira a linha do eixo de baixo, que ficaria longe do zero quando há negativos |

### Barras horizontais (ranking)

Barras em azul-marinho, com a categoria discutida em vermelho.

```r
ranking <- data.frame(
  grupo = c("Educação", "Saúde", "Alimentação", "Habitação", "Transportes", "Vestuário"),
  valor = c(5.95, 5.75, 4.66, 4.22, 3.94, 3.34)
)
ranking$grupo <- ordenar(ranking$grupo, ranking$valor)    # maior no topo

g <- ggplot(ranking, aes(valor, grupo, fill = destacar(grupo, "Alimentação"))) +
  geom_col(width = 0.7) +
  linha_zero(horizontal = TRUE) +
  rotulos_barras(ranking, "grupo", "valor", horizontal = TRUE, formato = pct_br(0.01)) +
  scale_fill_destaque() +
  scale_x_continuous(labels = pct_br(), expand = expansion(mult = c(0, 0.15))) +
  labs(x = NULL, y = NULL) +
  theme_macroliga(grade = "x", eixo = "nenhum")

salvar_macroliga(g, "ranking.png", "carrossel")
```

- **Ordene antes do ggplot** com `ordenar()`. Assim as barras e os rótulos ficam na mesma ordem.
- `destacar(grupo, "Alimentação")` pinta a categoria de vermelho. Para não destacar nenhuma, use `fill = cores_macroliga[["azul_marinho"]]` dentro de `geom_col()` e tire o `scale_fill_destaque()`.
- O valor da categoria no eixo y vai em `aes(valor, grupo)`: o valor no x e as categorias no y.
- Com valores negativos, dê folga também à esquerda: `expansion(mult = c(0.15, 0.15))`.
- Com mais de 12 categorias, salve no formato `"vertical"` (veja o exemplo 6).

### Contribuições empilhadas

Colunas empilhadas por componente e o total como linha.

```r
contrib <- data.frame(
  data        = rep(seq(as.Date("2025-01-01"), by = "quarter", length.out = 4), each = 4),
  componente  = rep(c("Consumo", "Investimento", "Governo", "Outros"), 4),
  valor       = c(0.9, 0.4, 0.2, -0.3,   0.6, -0.2, 0.1, 0.2,
                  0.5, 0.3, 0.2, -0.4,   0.7, 0.1, 0.1, 0.3)
)
contrib$componente <- factor(contrib$componente,
                             levels = c("Consumo", "Investimento", "Governo", "Outros"))

g <- ggplot() +
  contribuicoes(contrib, x = "data", y = "valor", grupo = "componente",
                nome_total = "PIB") +
  scale_x_date(labels = mes_br(), breaks = unique(contrib$data)) +   # um rótulo por coluna
  scale_y_continuous(labels = num_br(0.1)) +
  labs(x = NULL, y = NULL) +
  theme_macroliga(eixo = "nenhum")

salvar_macroliga(g, "contribuicoes.png", "carrossel")
```

| Opção | O que faz |
| --- | --- |
| `grupo` | Coluna dos componentes: até 4 + `"Outros"` (ponha "Outros" como último nível) |
| `total` | Sem nada, soma os componentes. Prefira passar o total oficial: uma tabela com as **mesmas colunas** `x` e `y`, ex.: `total = data.frame(data = ..., valor = ...)` |
| `nome_total` | Nome do total na legenda |
| `largura` | Largura das colunas (padrão `0.75`) |

A função já inclui a linha do zero e as cores. Repare que o gráfico começa com `ggplot()` vazio: os dados vão dentro de `contribuicoes()`.

### Linha com faixa (meta)

```r
dados <- data.frame(
  data  = seq(as.Date("2024-01-01"), by = "month", length.out = 24),
  valor = c(4.5, 4.3, 3.9, 3.7, 3.9, 4.2, 4.5, 4.2, 4.4, 4.8, 4.9, 4.8,
            4.6, 5.1, 5.5, 5.5, 5.3, 5.4, 5.2, 5.1, 5.2, 4.7, 4.5, 4.3)
)
meta <- meta_inflacao(min(dados$data), max(dados$data))

g <- ggplot(dados, aes(data, valor)) +
  banda(meta, x = "data", inferior = "inferior", superior = "superior",
        centro = "centro", rotulo = "Intervalo da meta") +
  geom_line(colour = cores_macroliga[["azul_marinho"]], linewidth = 1.1) +
  rotulos_finais(dados, x = "data", y = "valor", formato = pct_br(0.1)) +
  scale_x_date(labels = mes_br(), date_breaks = "6 months",
               expand = expansion(mult = c(0.01, 0.12))) +
  scale_y_continuous(labels = pct_br(), limits = c(0, NA)) +
  labs(x = NULL, y = NULL) +
  theme_macroliga()

salvar_macroliga(g, "meta.png", "grafico_comentado")
```

- `meta_inflacao(inicio, fim)` devolve a meta do CMN (centro, limite inferior e superior) em degraus anuais, de 2006 em diante.
- `banda()` serve para qualquer faixa: basta uma tabela com uma coluna de limite inferior e outra de superior (ex.: intervalo de projeções).
- `banda()` vem **antes** de `geom_line()`, para a linha ficar por cima.

### Períodos sombreados

```r
g <- ggplot(dados, aes(data, valor)) +
  periodos("2024-06-01", "2024-12-31", rotulo = "Enchentes no RS") +
  geom_line(colour = cores_macroliga[["azul_marinho"]], linewidth = 1.1) +
  rotulos_finais(dados, x = "data", y = "valor", formato = pct_br(0.1)) +
  scale_x_date(labels = mes_br(), date_breaks = "6 months",
               expand = expansion(mult = c(0.01, 0.12))) +
  scale_y_continuous(labels = pct_br()) +
  labs(x = NULL, y = NULL) +
  theme_macroliga()
```

- `periodos(inicio, fim, rotulo)` aceita vários períodos de uma vez: `periodos(c("2008-10-01", "2014-04-01"), c("2009-03-31", "2016-12-31"))`.
- Para as recessões datadas pelo CODACE, use `periodos(recessoes_codace$inicio, recessoes_codace$fim)` (exemplo 9).
- Explique o sombreado no template ou na legenda (ex.: "Áreas cinza: recessões, CODACE/FGV").

### Dispersão

```r
disp <- data.frame(
  mes        = mes_br()(seq(as.Date("2025-01-01"), by = "month", length.out = 12)),
  desemprego = c(6.5, 6.8, 7.0, 6.6, 6.2, 5.8, 5.6, 5.6, 5.6, 5.4, 5.2, 5.1),
  inflacao   = c(4.6, 5.1, 5.5, 5.5, 5.3, 5.4, 5.2, 5.1, 5.2, 4.7, 4.5, 4.3)
)
ultimo <- disp$mes[nrow(disp)]

g <- ggplot(disp, aes(desemprego, inflacao, fill = destacar(mes, ultimo))) +
  tendencia() +
  pontos() +
  rotulos_pontos(disp, x = "desemprego", y = "inflacao", rotulo = "mes",
                 quais = c(disp$mes[1], ultimo)) +
  scale_fill_destaque() +
  scale_x_continuous(labels = pct_br()) +
  scale_y_continuous(labels = pct_br()) +
  labs(x = "Taxa de desocupação", y = "IPCA em 12 meses") +
  theme_macroliga(grade = "ambas")

salvar_macroliga(g, "dispersao.png", "carrossel")
```

| Peça | O que faz |
| --- | --- |
| `pontos()` | Pontos azul-marinho com um anel na cor do fundo, que separa pontos sobrepostos |
| `fill = destacar(...)` + `scale_fill_destaque()` | Pinta de vermelho o ponto discutido (o último mês, ou o Brasil entre países) |
| `tendencia()` | Reta de tendência tracejada. É só referência visual, não prova causalidade |
| `rotulos_pontos(..., quais = ...)` | Escreve o nome de **poucos** pontos escolhidos, desviando dos demais |

- Na dispersão os dois eixos são grandezas, então **nomeie os eixos** em `labs()`, mesmo nas redes.
- Os pontos são desenhados na ordem da tabela. Deixe o destaque na última linha para ele não ficar escondido.
- Sem destaque: `pontos(fill = cores_macroliga[["azul_marinho"]])` e sem `scale_fill_destaque()`.

### Haltere

Dois momentos por categoria, ligados por um traço. Azul = antes, vermelho = agora.

```r
halt <- data.frame(
  uf      = rep(c("Bahia", "Pernambuco", "São Paulo", "Rio Grande do Sul", "Santa Catarina"), 2),
  momento = rep(c("2019", "2026"), each = 5),
  valor   = c(17.3, 16.0, 12.8, 8.2, 6.0,   9.1, 8.3, 5.4, 4.2, 2.1)
)
halt$momento <- factor(halt$momento, levels = c("2019", "2026"))       # ordem cronológica
halt$uf <- ordenar(halt$uf, ifelse(halt$momento == "2026", halt$valor, NA))

g <- ggplot() +
  haltere(halt, categoria = "uf", valor = "valor", momento = "momento") +
  scale_x_continuous(labels = pct_br()) +
  labs(x = NULL, y = NULL) +
  theme_macroliga(grade = "x", eixo = "nenhum")

salvar_macroliga(g, "haltere.png", "carrossel")
```

- `momento` precisa ter exatamente 2 valores, e o fator deve estar em ordem cronológica.
- `ordenar(..., ifelse(momento == "2026", valor, NA))` ordena as categorias pelo valor mais recente. O `NA` faz o outro momento ser ignorado.
- O eixo não precisa começar no zero, porque o que se lê é a distância entre os pontos.

### Cascata

Mostra como se chega de um número a outro, parcela por parcela.

```r
ponte <- data.frame(
  etapa = c("Dívida 2024", "Juros", "Resultado primário", "Crescimento do PIB", "Outros"),
  valor = c(76.1, 6.0, 0.4, -3.1, -0.6)
)

g <- ggplot() +
  cascata(ponte, etapa = "etapa", valor = "valor",
          totais = "Dívida 2024", total_final = "Dívida 2025") +
  scale_y_continuous(labels = num_br(1)) +
  labs(x = NULL, y = NULL) +
  theme_macroliga(eixo = "nenhum")

salvar_macroliga(g, "cascata.png", "carrossel")
```

| Opção | O que faz |
| --- | --- |
| `etapa`, `valor` | Uma linha por barra, **na ordem em que devem aparecer** |
| `totais` | Etapas que são níveis (barra do zero até o valor), como o ponto de partida. As demais são variações e "flutuam" sobre o acumulado |
| `total_final` | Acrescenta uma última barra com o acumulado. Deixe `NULL` para não ter |
| `formato` | Formato dos rótulos (variações saem com sinal: +6,0 e -3,1) |
| `quebra` | Quantas letras cabem por linha nos nomes do eixo x (padrão `10`) |

- Cores: variação positiva em azul, negativa em vermelho, totais em cinza.
- Use até ~6 barras; some as parcelas pequenas em "Outros". Com mais de 7 barras, os nomes alternam em duas linhas.
- Na cascata do exemplo 12, sem ponto de partida, a primeira barra já é uma variação a partir do zero.

### Pequenos múltiplos

Um painel por série, todos com a mesma escala. As demais séries aparecem em cinza no fundo.

```r
set.seed(1)
multi <- expand.grid(data  = seq(as.Date("2023-01-01"), by = "month", length.out = 36),
                     grupo = c("Argentina", "Brasil", "Chile", "Colômbia", "México", "Peru"))
multi$valor <- 4 + ave(rnorm(nrow(multi), sd = 0.4), multi$grupo, FUN = cumsum)

g <- ggplot(multi, aes(data, valor)) +
  contexto_facetas(multi, x = "data", y = "valor", faceta = "grupo") +
  geom_line(colour = cores_macroliga[["azul_marinho"]], linewidth = 0.9) +
  rotulos_finais(multi, x = "data", y = "valor", faceta = "grupo",
                 formato = pct_br(0.1), tamanho = 4.4) +
  facet_wrap(~ grupo, ncol = 3) +
  scale_x_date(date_labels = "%Y", expand = expansion(mult = c(0.02, 0.30))) +
  scale_y_continuous(labels = pct_br()) +
  labs(x = NULL, y = NULL) +
  theme_macroliga(base_size = 14)

salvar_macroliga(g, "pequenos_multiplos.png", "carrossel")
```

- `facet_wrap(~ grupo, ncol = 3)` cria um painel por valor da coluna `grupo`, em 3 colunas.
- **Mantenha a mesma escala y** em todos os painéis. Não use `scales = "free_y"`, que faz séries diferentes parecerem iguais.
- `contexto_facetas()` vem antes da linha; `rotulos_finais(..., faceta = "grupo")` marca o último dado de cada painel.
- Com 6 a 9 painéis, `theme_macroliga(base_size = 14)` deixa os textos proporcionais.

### Curva de juros

O eixo x é o prazo, e não a data.

```r
curva <- data.frame(
  data  = rep(c("09/10/2025", "09/10/2026"), each = 6),
  prazo = rep(c(0.5, 1, 2, 3, 5, 10), 2),
  taxa  = c(14.9, 14.1, 13.5, 13.5, 13.8, 14.0,
            13.4, 12.6, 12.4, 12.5, 12.7, 12.7)
)
curva$data <- factor(curva$data, levels = c("09/10/2025", "09/10/2026"))

g <- ggplot(curva, aes(prazo, taxa, colour = data)) +
  geom_line(linewidth = 1) +
  geom_point(size = 2.6) +
  rotulos_finais(curva, x = "prazo", y = "taxa", grupo = "data", formato = pct_br(0.01)) +
  scale_colour_macroliga() +
  scale_x_continuous(labels = anos_br(), breaks = c(1, 3, 5, 10),
                     expand = expansion(mult = c(0.02, 0.32))) +
  scale_y_continuous(labels = pct_br(0.5)) +
  labs(x = NULL, y = NULL) +
  theme_macroliga()

salvar_macroliga(g, "curva.png", "grafico_comentado")
```

- Compare no máximo 4 datas. A mais antiga vem primeiro no fator e fica azul.
- Escolha marcos inteiros em `breaks`, para o eixo mostrar "1 ano", "5 anos" etc.
- Para os dados reais do Tesouro Direto, veja o exemplo 14 e [`tesouro_direto()`](#tesouro-direto).

---

## Baixar dados

As três funções devolvem uma tabela (`data.frame`) pronta para o ggplot. Todas precisam de internet.

### Banco Central (SGS)

```r
selic <- sgs(432, inicio = "01/01/2020")                       # do início de 2020 até hoje
ipca  <- sgs(433, inicio = "01/01/2023", fim = "31/12/2024")   # um intervalo
```

- Devolve as colunas `data` e `valor`. As datas são no formato `"dd/mm/aaaa"`.
- Procure o código da série em [www3.bcb.gov.br/sgspub](https://www3.bcb.gov.br/sgspub).
- Séries diárias (como a Selic, 432) **exigem** `inicio`. Períodos longos são baixados em partes automaticamente.

| Código | Série |
| --- | --- |
| 432 | Meta Selic definida pelo Copom (% a.a.) |
| 433 | IPCA, variação mensal (%) |
| 13522 | IPCA acumulado em 12 meses (%) |
| 24364 | IBC-Br com ajuste sazonal (índice) |
| 24369 | Taxa de desocupação, PNAD Contínua (%) |

### IBGE (SIDRA)

```r
desemprego_uf <- sidra("t/4099/n3/all/v/4099/p/last%201")
```

1. Monte a consulta no [construtor da API do SIDRA](https://apisidra.ibge.gov.br): escolha a tabela, a variável, o período e o nível territorial.
2. Copie o trecho depois de `/values/` e passe para `sidra()`.
3. A tabela volta com os nomes de coluna do SIDRA (ex.: `"Unidade da Federação"`, `"Mês (Código)"`) e uma coluna `valor` numérica. Como os nomes têm espaços e acentos, use colchetes duplos: `desemprego_uf[["Unidade da Federação"]]`.

Pedaços úteis do caminho: `n1/all` = Brasil, `n3/all` = todas as UFs, `p/last%2012` = últimos 12 períodos, `p/202401-202412` = um intervalo. Para transformar o código do mês em data:

```r
ipca_grupos <- sidra("t/7060/n1/all/v/63/p/last%2012/c315/7169")
ipca_grupos$data <- as.Date(paste0(ipca_grupos[["Mês (Código)"]], "01"), "%Y%m%d")
```

### Tesouro Direto

```r
td <- tesouro_direto("td.csv")     # baixa na 1ª vez e guarda em td.csv; depois só lê
```

- Colunas: `tipo`, `vencimento`, `data_base`, `taxa_compra`, `taxa_venda`, `pu_base` (taxas em % ao ano).
- O arquivo tem ~15 MB. Com um nome de arquivo, ele é baixado só uma vez; apague o arquivo para atualizar. Sem nome, é baixado toda vez.
- Para curvas de juros, use `taxa_venda`, que existe para todos os títulos em estoque.

---

## Regras do padrão

- **Para as redes, sem título no gráfico.** O título, a unidade e a fonte ficam no template do Canva. Use `labs(title, subtitle, caption)` só quando o gráfico sair sem o template, como no site ou no fascículo.
- **Uma série:** azul-marinho, com o último dado em vermelho.
- **Duas a quatro séries:** `scale_colour_macroliga()` e `rotulos_finais(..., grupo = "serie")`. Com mais de 4, some as menores em **"Outros"** (cinza). Se nem assim couber, use pequenos múltiplos.
- **Nunca use dois eixos y.** Faça dois gráficos ou converta para índice com base 100.
- **Rotule pouco.** Escreva o valor do dado discutido no comentário, e não de todos os pontos.
- **O papel do vermelho muda conforme o gráfico:**

| Gráfico | O vermelho marca... |
| --- | --- |
| Linha de uma série | O destaque: o dado discutido no comentário |
| Comparação de séries | A 2ª série (azul contra vermelho, como no logo) |
| Colunas | Os valores negativos |
| Ranking em barras | A categoria discutida |
| Dispersão | O ponto discutido |
| Haltere | O momento mais recente |
| Cascata | As variações negativas |

- **Atualize as tabelas fixas** quando houver novidade: `metas_cmn` (metas do CMN) e `recessoes_codace` (recessões do CODACE) estão escritas no `tema_macroliga.R`.

---

## Problemas comuns

**Aparece `[MacroLiga] Inter e/ou Libre Baskerville não encontradas`.**
As fontes não estão instaladas, ou o R não foi reiniciado depois da instalação. No Windows, instale "para todos os usuários". Para conferir, rode `"Inter" %in% systemfonts::system_fonts()$family`: deve dar `TRUE`.

**Os acentos aparecem estranhos (ex.: "ElaboraÃ§Ã£o").**
Carregue o tema com `encoding = "UTF-8"`: `source("tema_macroliga.R", encoding = "UTF-8")`. Salve os seus scripts em UTF-8 também (no RStudio: *File › Save with Encoding › UTF-8*).

**`cannot open file 'tema_macroliga.R': No such file or directory`.**
O R está olhando para outra pasta. Rode `getwd()` para ver qual. Mude com *Session › Set Working Directory › To Source File Location* ou passe o caminho completo do arquivo.

**`não foi possível encontrar a função "theme_macroliga"` (ou `could not find function`).**
O tema não foi carregado nesta sessão. Rode o `source(...)` antes do gráfico. Reiniciar o R apaga tudo o que foi carregado.

**`[MacroLiga] Mais de 4 séries (fora 'Outros')`.**
Há mais de 4 séries com cores. Agrupe as menores em `"Outros"` ([veja como](#cores)) ou use pequenos múltiplos.

**O rótulo do último dado aparece cortado na direita.**
Aumente a folga do eixo x: `scale_x_date(expand = expansion(mult = c(0.01, 0.15)))`. Em barras horizontais, o mesmo vale para `scale_x_continuous()`.

**O gráfico ficou diferente na prévia e no arquivo.**
É normal: a aba *Plots* tem outro tamanho. Vale o arquivo salvo por `salvar_macroliga()`.

**O PNG do fascículo aparece com fundo preto ou xadrez.**
É o fundo transparente, que alguns visualizadores mostram assim. No fascículo ele fica sobre a cor da página. Se precisar de fundo branco, use `transparente = FALSE`.

**Aparece `[MacroLiga] Formato vertical com datas no eixo x` ou `Ranking com mais de 12 categorias`.**
É só um aviso: o arquivo foi salvo. Ele sugere trocar o formato, porque séries no tempo ficam melhores na horizontal e rankings longos na vertical.

**Aparece `Coordinate system already present`.**
Duas funções de rótulo no mesmo gráfico (ex.: `rotulos_finais()` e `rotulos_barras()`) acrescentaram a mesma configuração. É inofensivo.

**`[MacroLiga] O SGS não respondeu à consulta da série ...`.**
Confira a internet e o código da série. Séries diárias exigem `inicio`. O site do BCB às vezes fica instável: tente de novo em alguns minutos.

---

## Lista de todas as funções

| Função | Para quê | Receita |
| --- | --- | --- |
| `theme_macroliga()` | Aparência: fundo, grade, eixo, fontes | [Opções](#theme_macroliga-a-aparência) |
| `salvar_macroliga()` | Exportar no tamanho de cada template | [Opções](#salvar_macroliga-exportar) |
| `cores_macroliga` | Cores da marca | [Cores](#cores) |
| `scale_colour_macroliga()` / `scale_fill_macroliga()` | Paleta de 2 a 4 séries, com "Outros" em cinza | [Comparação](#comparação-de-2-a-4-séries) |
| `rotulos_finais()` | Valor no último dado de linhas | [Opções](#rotulos_finais-o-valor-no-último-dado) |
| `sinal()` + `scale_fill_sinal()` | Colunas azuis (positivas) e vermelhas (negativas) | [Colunas](#colunas) |
| `ordenar()` | Ordena categorias pelo valor | [Ranking](#barras-horizontais-ranking) |
| `destacar()` + `scale_fill_destaque()` | Pinta de vermelho a categoria ou ponto discutido | [Ranking](#barras-horizontais-ranking) |
| `linha_zero()` | Linha de base no zero | [Colunas](#colunas) |
| `rotulos_barras()` | Valor na ponta das barras | [Colunas](#colunas) |
| `contribuicoes()` | Colunas empilhadas + total | [Contribuições](#contribuições-empilhadas) |
| `banda()` | Faixa sombreada entre dois limites | [Faixa](#linha-com-faixa-meta) |
| `meta_inflacao()` / `metas_cmn` | Metas de inflação do CMN | [Faixa](#linha-com-faixa-meta) |
| `periodos()` / `recessoes_codace` | Períodos sombreados | [Períodos](#períodos-sombreados) |
| `pontos()` | Pontos da dispersão | [Dispersão](#dispersão) |
| `tendencia()` | Reta de tendência | [Dispersão](#dispersão) |
| `rotulos_pontos()` | Nome de poucos pontos | [Dispersão](#dispersão) |
| `haltere()` | Dois momentos por categoria | [Haltere](#haltere) |
| `cascata()` | Ponte entre dois números | [Cascata](#cascata) |
| `contexto_facetas()` | Séries em cinza no fundo dos painéis | [Pequenos múltiplos](#pequenos-múltiplos) |
| `num_br()` / `pct_br()` / `mes_br()` / `anos_br()` | Números, datas e prazos no formato brasileiro | [Formatos](#números-datas-e-prazos-no-formato-brasileiro) |
| `fonte_macroliga()` | Texto "Fonte: …. Elaboração: MacroLiga UFRGS." | [Linha](#linha-uma-série) |
| `sgs()` | Dados do Banco Central | [Baixar dados](#banco-central-sgs) |
| `sidra()` | Dados do IBGE | [Baixar dados](#ibge-sidra) |
| `tesouro_direto()` | Taxas do Tesouro Direto | [Baixar dados](#tesouro-direto) |
