# =============================================================================
# exemplos.R — Como usar o tema da MacroLiga
# Rode com o tema_macroliga.R na mesma pasta.
# =============================================================================
source("tema_macroliga.R", encoding = "UTF-8")

# -----------------------------------------------------------------------------
# Exemplo 1 — Série única para o post "Gráfico Comentado"
# Sem título no gráfico: título, unidade e fonte ficam no template do Canva.
# (Dados ilustrativos: taxa de poupança pessoal dos EUA, base "economics" do
#  ggplot2. Troque pela sua série; veja o Exemplo 3 para dados do BCB.)
# -----------------------------------------------------------------------------
dados1 <- subset(economics, date >= as.Date("2000-01-01"))

g1 <- ggplot(dados1, aes(date, psavert)) +
  geom_line(colour = cores_macroliga[["azul_marinho"]], linewidth = 1.1) +
  rotulos_finais(dados1, x = "date", y = "psavert", formato = pct_br(0.1)) +
  scale_x_date(date_labels = "%Y", expand = expansion(mult = c(0.01, 0.10))) +
  scale_y_continuous(labels = pct_br(), limits = c(0, NA),
                     expand = expansion(mult = c(0, 0.05))) +
  labs(x = NULL, y = NULL) +
  theme_macroliga()


salvar_macroliga(g1, "exemplo1_grafico_comentado.png", "grafico_comentado")

# -----------------------------------------------------------------------------
# Exemplo 2 — Comparação de até 4 séries (paleta categórica + rótulos diretos)
# Mesmo eixo, mesma unidade: índices com base 100 (nunca use dois eixos y).
# (Dados ilustrativos: bolsas europeias 1991-1998, base "EuStockMarkets".)
# -----------------------------------------------------------------------------
eu <- as.data.frame(EuStockMarkets)
t <- as.numeric(time(EuStockMarkets))                # ano decimal
eu$data <- as.Date(paste0(floor(t), "-01-01")) + round((t %% 1) * 365.25)
longo <- do.call(rbind, lapply(c("DAX", "SMI", "CAC", "FTSE"), function(s)
  data.frame(data = eu$data, serie = s, valor = 100 * eu[[s]] / eu[[s]][1])))
longo$serie <- factor(longo$serie, levels = c("DAX", "SMI", "CAC", "FTSE"))

g2 <- ggplot(longo, aes(data, valor, colour = serie)) +
  geom_hline(yintercept = 100, colour = cores_macroliga[["grafite"]], linewidth = 0.4) +
  geom_line(linewidth = 0.9) +
  rotulos_finais(longo, x = "data", y = "valor", grupo = "serie",
                 formato = num_br(1)) +
  scale_colour_macroliga() +
  scale_x_date(date_labels = "%Y", expand = expansion(mult = c(0.01, 0.16))) +
  scale_y_continuous(labels = num_br(1)) +
  labs(x = NULL, y = NULL) +
  theme_macroliga()

salvar_macroliga(g2, "exemplo2_comparacao.png", "carrossel")

# -----------------------------------------------------------------------------
# Exemplo 3 — Dados do Banco Central + versão completa para o site/fascículo
# (precisa de internet e do pacote jsonlite)
# -----------------------------------------------------------------------------
library(jsonlite)

selic <- sgs(432, inicio = "01/01/2016")
g3 <- ggplot(selic, aes(data, valor)) +
  geom_step(colour = cores_macroliga[["azul_marinho"]], linewidth = 0.8) +
  rotulos_finais(selic, x = "data", y = "valor", formato = pct_br(0.01),
                 tamanho = 3.4) +
  scale_x_date(date_labels = "%Y", expand = expansion(mult = c(0.01, 0.10))) +
  scale_y_continuous(labels = pct_br(), limits = c(0, NA),
                     expand = expansion(mult = c(0, 0.05))) +
  labs(title = "Selic: título que afirma o fato",
       subtitle = "Meta da taxa Selic, % ao ano",
       caption = fonte_macroliga("Banco Central do Brasil, SGS, série 432"),
       x = NULL, y = NULL) +
  theme_macroliga(base_size = 10)
salvar_macroliga(g3, "selic_publicacao.png", "publicacao")


# =============================================================================
# Novos tipos de gráfico (precisam de internet: dados do BCB e do IBGE)
# =============================================================================

# -----------------------------------------------------------------------------
# Exemplo 4 — Colunas: azul para positivo, vermelho para negativo
# IPCA mensal dos últimos 24 meses. Com muitas colunas, rotule só a última
# (o dado discutido no comentário).
# -----------------------------------------------------------------------------
ipca_m <- tail(sgs(433, inicio = format(Sys.Date() - 800, "%d/%m/%Y")), 24)

g4 <- ggplot(ipca_m, aes(data, valor, fill = sinal(valor))) +
  geom_col() +
  linha_zero() +
  rotulos_barras(ipca_m, "data", "valor", formato = pct_br(0.01), quais = "todos") +
  scale_fill_sinal() +
  scale_x_date(labels = mes_br(), date_breaks = "3 months",
               expand = expansion(mult = 0.02)) +
  scale_y_continuous(labels = pct_br(0.1), expand = expansion(mult = 0.1)) +
  labs(x = NULL, y = NULL) +
  theme_macroliga(eixo = "nenhum")

salvar_macroliga(g4, "exemplo4_colunas.png", "grafico_comentado")

g4 <- ggplot(ipca_m, aes(data, valor, fill = sinal(valor))) +
  geom_col() +
  linha_zero() +
  rotulos_barras(ipca_m, "data", "valor", formato = pct_br(0.01), quais = "todos") +
  scale_fill_sinal() +
  scale_x_date(labels = mes_br(), date_breaks = "3 months",
               expand = expansion(mult = 0.02)) +
  scale_y_continuous(labels = pct_br(0.1), expand = expansion(mult = 0.1)) +
  labs(x = NULL, y = NULL) +
  theme_macroliga(eixo = "nenhum")

# -----------------------------------------------------------------------------
# Exemplo 5 — Barras horizontais ordenadas (ranking), com um destaque
# IPCA acumulado em 12 meses por grupo (IBGE, SIDRA, tabela 7060).
# -----------------------------------------------------------------------------
grupos <- sidra(paste0("t/7060/n1/all/v/2265/p/last%201/c315/",
                       "7170,7445,7486,7558,7625,7660,7712,7766,7786"))
grupos$grupo <- sub("^[0-9]+[.]", "", grupos[["Geral, grupo, subgrupo, item e subitem"]])
grupos$grupo <- ordenar(grupos$grupo, grupos$valor)   # maior no topo

g5 <- ggplot(grupos, aes(valor, grupo, fill = destacar(grupo, "Alimentação e bebidas"))) +
  geom_col(width = 0.7) +
  linha_zero(horizontal = TRUE) +
  rotulos_barras(grupos, "grupo", "valor", horizontal = TRUE, formato = pct_br(0.01)) +
  scale_fill_destaque() +
  # espaço para os rótulos; à esquerda só se houver valor negativo
  scale_x_continuous(labels = pct_br(),
                     expand = expansion(mult = c(if (min(grupos$valor) < 0) 0.15 else 0, 0.15))) +
  labs(x = NULL, y = NULL) +
  theme_macroliga(grade = "x", eixo = "nenhum")

salvar_macroliga(g5, "exemplo5_ranking.png", "carrossel")

# -----------------------------------------------------------------------------
# Exemplo 6 — Ranking longo em formato vertical
# Taxa de desocupação por UF (PNAD Contínua, SIDRA, tabela 4099), RS em destaque.
# Com 27 categorias, o formato "vertical" dá altura para todas as barras.
# -----------------------------------------------------------------------------
desemprego <- sidra("t/4099/n3/all/v/4099/p/last%201")
desemprego$uf <- ordenar(desemprego[["Unidade da Federação"]], desemprego$valor)

g6 <- ggplot(desemprego, aes(valor, uf, fill = destacar(uf, "Rio Grande do Sul"))) +
  geom_col(width = 0.7) +
  linha_zero(horizontal = TRUE) +
  rotulos_barras(desemprego, "uf", "valor", horizontal = TRUE, formato = pct_br(0.1)) +
  scale_fill_destaque() +
  scale_x_continuous(labels = pct_br(), expand = expansion(mult = c(0, 0.12))) +
  labs(x = NULL, y = NULL) +
  theme_macroliga(grade = "x", eixo = "nenhum")

salvar_macroliga(g6, "exemplo6_ranking_vertical.png", "vertical")

# -----------------------------------------------------------------------------
# Exemplo 7 — Contribuições empilhadas + linha do total
# Contribuição dos grupos para o IPCA mensal (variação x peso / 100), com os
# 4 maiores grupos e o resto somado em "Outros" (sempre cinza).
# -----------------------------------------------------------------------------
ipca_g <- sidra(paste0("t/7060/n1/all/v/63,66/p/last%2012/c315/",
                       "7169,7170,7445,7486,7558,7625,7660,7712,7766,7786"))
ipca_g$data  <- as.Date(paste0(ipca_g[["Mês (Código)"]], "01"), "%Y%m%d")
ipca_g$grupo <- sub("^[0-9]+[.]", "", ipca_g[["Geral, grupo, subgrupo, item e subitem"]])
variacao <- subset(ipca_g, ipca_g[["Variável (Código)"]] == "63")
peso     <- subset(ipca_g, ipca_g[["Variável (Código)"]] == "66")
contrib  <- merge(variacao[, c("data", "grupo", "valor")], peso[, c("data", "grupo", "valor")],
                  by = c("data", "grupo"), suffixes = c("_var", "_peso"))
contrib  <- subset(contrib, grupo != "Índice geral")
contrib$contribuicao <- contrib$valor_var * contrib$valor_peso / 100

principais <- c(Alimentação = "Alimentação e bebidas", Habitação = "Habitação",
                Transportes = "Transportes", Saúde = "Saúde e cuidados pessoais")
contrib$componente <- ifelse(contrib$grupo %in% principais,
                             names(principais)[match(contrib$grupo, principais)], "Outros")
contrib <- aggregate(contribuicao ~ data + componente, data = contrib, FUN = sum)
contrib$componente <- factor(contrib$componente, levels = c(names(principais), "Outros"))

# Total oficial (índice geral), com os mesmos nomes de coluna do x e do y
total_ipca <- subset(variacao, grupo == "Índice geral", select = c(data, valor))
names(total_ipca) <- c("data", "contribuicao")

g7 <- ggplot() +
  contribuicoes(contrib, "data", "contribuicao", "componente",
                total = total_ipca, nome_total = "IPCA") +
  scale_x_date(labels = mes_br(), date_breaks = "2 months",
               expand = expansion(mult = 0.03)) +
  scale_y_continuous(labels = pct_br(0.1)) +
  labs(x = NULL, y = NULL) +
  theme_macroliga(eixo = "nenhum")

salvar_macroliga(g7, "exemplo7_contribuicoes.png", "carrossel")

# -----------------------------------------------------------------------------
# Exemplo 8 — Linha com faixa: IPCA em 12 meses e o intervalo da meta
# meta_inflacao() monta as metas do CMN em degraus anuais.
# -----------------------------------------------------------------------------
ipca12 <- sgs(13522, inicio = "01/01/2017")
meta   <- meta_inflacao(min(ipca12$data), max(ipca12$data))

g8 <- ggplot(ipca12, aes(data, valor)) +
  banda(meta, "data", "inferior", "superior", centro = "centro",
        rotulo = "Intervalo da meta") +
  geom_line(colour = cores_macroliga[["azul_marinho"]], linewidth = 1.1) +
  rotulos_finais(ipca12, x = "data", y = "valor", formato = pct_br(0.01)) +
  scale_x_date(date_labels = "%Y", expand = expansion(mult = c(0.01, 0.10))) +
  scale_y_continuous(labels = pct_br(), limits = c(0, NA),
                     expand = expansion(mult = c(0, 0.05))) +
  labs(x = NULL, y = NULL) +
  theme_macroliga()

salvar_macroliga(g8, "exemplo8_meta_inflacao.png", "grafico_comentado")

# -----------------------------------------------------------------------------
# Exemplo 9 — Linha com períodos sombreados: IBC-Br e recessões (CODACE)
# Explique o sombreado no template (ex.: "Áreas cinza: recessões, CODACE/FGV").
# -----------------------------------------------------------------------------
ibc <- sgs(24364, inicio = "01/01/2006")

g9 <- ggplot(ibc, aes(data, valor)) +
  periodos(recessoes_codace$inicio, recessoes_codace$fim) +
  geom_line(colour = cores_macroliga[["azul_marinho"]], linewidth = 1) +
  rotulos_finais(ibc, x = "data", y = "valor", formato = num_br(0.1)) +
  scale_x_date(date_labels = "%Y", expand = expansion(mult = c(0.01, 0.08))) +
  scale_y_continuous(labels = num_br(1)) +
  labs(x = NULL, y = NULL) +
  theme_macroliga()

salvar_macroliga(g9, "exemplo9_recessoes.png", "linkedin")


# =============================================================================
# Prioridade 2: dispersão, haltere, cascata, pequenos múltiplos e curva de juros
# =============================================================================

# Grupos do IPCA (códigos da tabela 7060 do SIDRA), na ordem do IBGE
grupos_ipca <- c("7170" = "Alimentação", "7445" = "Habitação",
                 "7486" = "Art. de residência", "7558" = "Vestuário",
                 "7625" = "Transportes", "7660" = "Saúde",
                 "7712" = "Desp. pessoais", "7766" = "Educação",
                 "7786" = "Comunicação")

# -----------------------------------------------------------------------------
# Exemplo 10 — Dispersão: curva de Phillips (desocupação x IPCA em 12 meses)
# Cada ponto é um mês; o último fica em vermelho. Rotule poucos pontos.
# -----------------------------------------------------------------------------
desoc    <- sgs(24369, inicio = "01/03/2012")   # desocupação, PNAD Contínua
infl     <- sgs(13522, inicio = "01/03/2012")
phillips <- merge(desoc, infl, by = "data", suffixes = c("_desoc", "_ipca"))
phillips$mes <- mes_br()(phillips$data)
ultimo   <- max(phillips$data)
marcados <- c(phillips$mes[1], phillips$mes[which.max(phillips$valor_ipca)],
              mes_br()(ultimo))

g10 <- ggplot(phillips, aes(valor_desoc, valor_ipca, fill = destacar(data, ultimo))) +
  tendencia() +
  pontos() +
  rotulos_pontos(phillips, "valor_desoc", "valor_ipca", "mes", quais = marcados) +
  scale_fill_destaque() +
  scale_x_continuous(labels = pct_br()) +
  scale_y_continuous(labels = pct_br()) +
  labs(x = "Taxa de desocupação", y = "IPCA em 12 meses") +
  theme_macroliga(grade = "ambas")

salvar_macroliga(g10, "exemplo10_dispersao.png", "carrossel")

# -----------------------------------------------------------------------------
# Exemplo 11 — Haltere: desocupação por UF antes da pandemia e agora
# Ordenado pelo momento mais recente; 27 UFs pedem o formato vertical.
# -----------------------------------------------------------------------------
uf_antes <- sidra("t/4099/n3/all/v/4099/p/201902")
uf_agora <- sidra("t/4099/n3/all/v/4099/p/last%201")
halt <- rbind(uf_antes, uf_agora)
halt$uf <- halt[["Unidade da Federação"]]
halt$momento <- factor(halt[["Trimestre"]],
                       levels = c(uf_antes[["Trimestre"]][1], uf_agora[["Trimestre"]][1]))
halt$uf <- ordenar(halt$uf, ifelse(halt$momento == levels(halt$momento)[2], halt$valor, NA))

g11 <- ggplot() +
  haltere(halt, "uf", "valor", "momento") +
  scale_x_continuous(labels = pct_br()) +
  labs(x = NULL, y = NULL) +
  theme_macroliga(grade = "x", eixo = "nenhum")

salvar_macroliga(g11, "exemplo11_haltere.png", "vertical")

# -----------------------------------------------------------------------------
# Exemplo 12 — Cascata: do zero ao IPCA do mês, grupo a grupo
# Contribuição = variação x peso / 100. A soma das contribuições pode diferir
# do índice oficial em 0,01 p.p. por arredondamento.
# -----------------------------------------------------------------------------
mes_g <- sidra(paste0("t/7060/n1/all/v/63,66/p/last%201/c315/",
                      paste(names(grupos_ipca), collapse = ",")))
mes_g$etapa <- grupos_ipca[mes_g[["Geral, grupo, subgrupo, item e subitem (Código)"]]]
var_m  <- subset(mes_g, mes_g[["Variável (Código)"]] == "63")
peso_m <- subset(mes_g, mes_g[["Variável (Código)"]] == "66")
cas <- merge(var_m[, c("etapa", "valor")], peso_m[, c("etapa", "valor")],
             by = "etapa", suffixes = c("_var", "_peso"))
cas$contribuicao <- cas$valor_var * cas$valor_peso / 100
# Os 4 grupos de maior contribuição (em módulo) e o resto em "Outros"
principais_m <- cas$etapa[order(-abs(cas$contribuicao))][1:4]
cas$etapa[!cas$etapa %in% principais_m] <- "Outros"
cas <- aggregate(contribuicao ~ etapa, data = cas, FUN = sum)
cas <- cas[order(cas$etapa == "Outros", -cas$contribuicao), ]   # "Outros" por último
mes_ref <- mes_br()(as.Date(paste0(mes_g[["Mês (Código)"]][1], "01"), "%Y%m%d"))

g12 <- ggplot() +
  cascata(cas, "etapa", "contribuicao", total_final = paste("IPCA", mes_ref),
          formato = num_br(0.01)) +
  scale_y_continuous(labels = num_br(0.1)) +
  labs(x = NULL, y = NULL) +
  theme_macroliga(eixo = "nenhum")

salvar_macroliga(g12, "exemplo12_cascata.png", "carrossel")

# -----------------------------------------------------------------------------
# Exemplo 13 — Pequenos múltiplos: IPCA em 12 meses dos 9 grupos
# Mesma escala y em todos os painéis; as demais séries em cinza no fundo.
# -----------------------------------------------------------------------------
hist_g <- sidra(paste0("t/7060/n1/all/v/2265/p/last%2060/c315/",
                       paste(names(grupos_ipca), collapse = ",")))
hist_g$data  <- as.Date(paste0(hist_g[["Mês (Código)"]], "01"), "%Y%m%d")
hist_g$grupo <- factor(grupos_ipca[hist_g[["Geral, grupo, subgrupo, item e subitem (Código)"]]],
                       levels = grupos_ipca)
hist_g <- subset(hist_g, !is.na(valor))

g13 <- ggplot(hist_g, aes(data, valor)) +
  contexto_facetas(hist_g, "data", "valor", "grupo") +
  geom_line(colour = cores_macroliga[["azul_marinho"]], linewidth = 0.9) +
  rotulos_finais(hist_g, x = "data", y = "valor", faceta = "grupo",
                 formato = pct_br(0.1), tamanho = 4.4) +
  facet_wrap(~ grupo, ncol = 3) +
  # marcos a cada 2 anos, sem anos além do último dado
  scale_x_date(date_labels = "%Y",
               breaks = function(lim) {
                 b <- breaks_width("2 years")(lim)
                 b[b <= max(hist_g$data)]
               },
               expand = expansion(mult = c(0.02, 0.30))) +
  scale_y_continuous(labels = pct_br()) +
  labs(x = NULL, y = NULL) +
  theme_macroliga(base_size = 14)

salvar_macroliga(g13, "exemplo13_pequenos_multiplos.png", "carrossel")

# -----------------------------------------------------------------------------
# Exemplo 14 — Curva de juros prefixada hoje e há um ano (Tesouro Direto)
# Prazo no eixo x em vez de data. Usa os títulos sem cupom (Tesouro
# Prefixado) e completa com o de juros semestrais nos prazos mais longos.
# O download tem ~15 MB; use tesouro_direto("td.csv") para guardar uma cópia.
# -----------------------------------------------------------------------------
td  <- tesouro_direto()
pre <- subset(td, tipo %in% c("Tesouro Prefixado", "Tesouro Prefixado com Juros Semestrais") &
                taxa_venda > 0)
datas <- c(max(pre$data_base[pre$data_base <= max(pre$data_base) - 365]),
           max(pre$data_base))
curva <- subset(pre, data_base %in% datas)
ult_ltn <- ave(ifelse(curva$tipo == "Tesouro Prefixado", as.numeric(curva$vencimento), 0),
               curva$data_base, FUN = max)
curva <- subset(curva, tipo == "Tesouro Prefixado" | as.numeric(vencimento) > ult_ltn)
curva$prazo <- as.numeric(curva$vencimento - curva$data_base) / 365.25
curva$data  <- factor(format(curva$data_base, "%d/%m/%Y"), levels = format(datas, "%d/%m/%Y"))
curva <- curva[order(curva$data, curva$prazo), ]

g14 <- ggplot(curva, aes(prazo, taxa_venda, colour = data)) +
  geom_line(linewidth = 1) +
  geom_point(size = 2.6) +
  rotulos_finais(curva, x = "prazo", y = "taxa_venda", grupo = "data",
                 formato = pct_br(0.01)) +
  scale_colour_macroliga() +
  scale_x_continuous(labels = anos_br(), breaks = c(1, 3, 5, 7, 10),
                     expand = expansion(mult = c(0.02, 0.32))) +
  scale_y_continuous(labels = pct_br(0.5)) +
  labs(x = NULL, y = NULL) +
  theme_macroliga()

salvar_macroliga(g14, "exemplo14_curva_juros.png", "grafico_comentado")
